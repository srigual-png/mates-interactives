MATES INTERACTIVES · 3r ESO · SENTIT ALGEBRAIC

Contingut del paquet:
- sentit-algebraic.html: blocs 1–9 + ampliacions A–D.
- teoria/algebraic/: teoria completa del sentit (13 pàgines + índex de teoria).

Per publicar-ho:
1. Puja sentit-algebraic.html dins la carpeta 3eso/ del projecte.
2. Puja la carpeta teoria/algebraic/ dins 3eso/ mantenint exactament aquesta estructura.
3. No cal moure cap fitxer d'imatges ni CSS: aquestes pàgines de teoria són autocontingudes.

Les pàgines de teoria enllacen de nou amb el sentit i permeten obrir directament el tema en nivell guiat o autònom.
